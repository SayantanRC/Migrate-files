#!sbin/sh

# parameters:

# TEMP_DIR_NAME

OUTFD="/dev/null"

for FD in `ls /proc/$$/fd`; do
	if readlink /proc/$$/fd/$FD | grep -q pipe; then
		if ps | grep -v grep | grep -q " 3 $FD "; then
			OUTFD=$FD
			break
		fi
	fi
done

echo "ui_print  " >> /proc/self/fd/$OUTFD;
echo "ui_print Checking parameters..." >> /proc/self/fd/$OUTFD;
echo "ui_print  " >> /proc/self/fd/$OUTFD;

res="$(cat /proc/cmdline | grep slot_suffix)";

if [ -n "$res" ];
then
	echo "ui_print A/B device." >> /proc/self/fd/$OUTFD;
	echo "ui_print Bind mounting system..." >> /proc/self/fd/$OUTFD;
	mount -o bind /system/system /system
	sleep 2s
else
	echo "ui_print Only-A device." >> /proc/self/fd/$OUTFD;
fi

echo "ui_print  " >> /proc/self/fd/$OUTFD;

mkdir -p /system/app/
mkdir -p /system/priv-app/
mkdir -p /data/app/
mkdir -p /data/data/

mkdir -p $1

#!sbin/sh

# This script only allows unpacking user apps and optional extras like calls, sms etc.
# This does not restore system apps
# The restoration process must be completed using the helper app.

OUTFD="/dev/null"

for FD in `ls /proc/$$/fd`; do
	if readlink /proc/$$/fd/$FD | grep -q pipe; then
		if ps | grep -v grep | grep -q " 3 $FD "; then
			OUTFD=$FD
			break
		fi
	fi
done

if [ -z $1 ]; then
    echo "ui_print Please provide path to extracted zip" >> /proc/self/fd/$OUTFD;
    exit 1
fi

CACHE=/data/local/tmp/migrate_cache/

# make cache
echo "ui_print Making cache" >> /proc/self/fd/$OUTFD;
mkdir -p $CACHE

# move inside the extracted backup
cd $1

files="$(ls . | wc -l)"
echo "ui_print Approximate number of files: $files" >> /proc/self/fd/$OUTFD;

echo "ui_print Copying apps" >> /proc/self/fd/$OUTFD;

# copy app info, apks and permission to cache
cp *.json $CACHE
cp -a *.app $CACHE
cp *.perm $CACHE

# copy app data
cp *.tar.gz /data/data/

# copy extras
echo "ui_print Copying extras" >> /proc/self/fd/$OUTFD;
cp *.calls.db $CACHE 2>/dev/null
cp *.sms.db $CACHE 2>/dev/null
cp *.vcf $CACHE 2>/dev/null
cp default.kyb $CACHE 2>/dev/null
cp screen.dpi $CACHE 2>/dev/null

# copy package data
echo "ui_print Copying package-data" >> /proc/self/fd/$OUTFD;
cp package-data* $CACHE

# inject helper
echo "ui_print Deleting and injecting helper" >> /proc/self/fd/$OUTFD;
rm -r /system/app/MigrateHelper 2>/dev/null
cp -a system /
mv /system/app/helper/ /system/app/MigrateHelper

echo "ui_print Done!! Please reboot." >> /proc/self/fd/$OUTFD;
